fetch('https://localhost:7200/api/Employee', {
    method: 'GET',
    headers: {
        'Content-Type': 'application/json',
    },
})
    .then(response => response.json())
    .then(data => console.log(data))
    .catch(error => console.log('Error:', error));


// Event listener for form submission
document.getElementById('submitBtn').addEventListener('click', async function (event) {
    event.preventDefault(); // Prevent form submission

    // Get form values
    const firstName = document.getElementById('Firstname').value.trim();
    const lastName = document.getElementById('Lastname').value.trim();
    const dateOfBirth = document.getElementById('DateOfBirth').value.trim();
    const mobileNumber = document.getElementById('MobileNumber').value.trim();
    const ad = document.getElementById('AlternateNumber').value.trim();
    console.log(ad);
    // Validate age
    if (!validateAge(dateOfBirth)) {
        alert('You must be between 18 and 60 years old to register.');
        return;
    }

    // Generate employee ID
    const employeeID = generateEmployeeID(firstName, lastName, mobileNumber);

    // Show employee ID in a popup with bright color
    // showEmployeeIDPopup(employeeID);

    // Reset form

    // Assuming you have a backend API endpoint for employee registration
    const method = document.getElementById('formMethod').value;
    const id = document.getElementById('formId').value;

    const data = {
        FirstName: firstName,
        LastName: lastName,
        Email: document.getElementById('Email').value,
        DateOfBirth: dateOfBirth,
        MobileNumber: mobileNumber,
        AlternateNumber: document.getElementById('AlternateNumber').value,
        CurrentAddress: document.getElementById('CurrentAddress').value,
        PermanentAddress: document.getElementById('PermanentAddress').value,
        Nationality: document.getElementById('Nationality').value,
        State: document.getElementById('State').value,
        city: document.getElementById('City').value,
        Pincode: document.getElementById('Pincode').value,
        CompanyName: document.getElementById('CompanyName').value,
        JoiningDate: document.getElementById('JoiningDate').value,
        CurrentCTC: document.getElementById('CurrentCTC').value,
        EmploymentType: document.getElementById('EmploymentType').value,
        documentType: document.getElementById('DocumentType').value,
        DocumentNumber: document.getElementById('DocumentNumber').value
    };
    console.log(JSON.stringify(data));
    // resetForm();

    try {
        const response = await fetch('https://localhost:7200/api/Employee', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(data),
        });

        const result = await response.json();
        console.log(JSON.stringify(result));
        console.log(result);

        let r = await result.data;
        if (response.ok) {
            // Show success message
            showSuccessMessage();

            // Show employee ID popup
            showEmployeeIDPopup(employeeID);

            // Optionally, remove popup after 5 seconds
            // setTimeout(() => {
            //     document.querySelector('.alert-primary').remove();
            // }, 5000);
        } else {
            console.log('Failed to submit form: ' + result, r);
        }
    } catch (error) {
        console.error('Error:', error);
        alert('An error occurred while submitting the form.');
    }
});

// Function to show success message
function showSuccessMessage() {
    const successMessage = `<div class="alert alert-success text-center mt-3" role="alert">Form submitted successfully!</div>`;
    const messageElement = document.createElement('div');
    messageElement.innerHTML = successMessage;
    document.body.appendChild(messageElement);

    // setTimeout(() => {
    //     showEmployeeIDPopup(employeeID);
    // }, 2000);

    // Optionally, remove success message after 5 seconds
    setTimeout(() => {
        messageElement.remove();
    }, 5000);
}

// Function to show employee ID popup
function showEmployeeIDPopup(employeeID) {
    const popupHTML = `<div class="alert alert-primary text-center mt-3" role="alert">Your Employee ID is: ${employeeID}</div>`;
    const popup = document.createElement('div');
    popup.innerHTML = popupHTML;
    popup.style.backgroundColor = '#87CEEB'; // Bright color
    document.body.appendChild(popup);
    setTimeout(() => {
        popup.remove();
    }, 5000);

}

// Event listener for form reset
document.getElementById('resetBtn').addEventListener('click', function () {
    if (confirm('Are you sure you want to reset the form?')) {
        // resetForm();
    }
});

// Event listener for Pending button
document.getElementById('pendingBtn').addEventListener('click', function () {
    this.innerHTML = 'Pending...';
    this.disabled = true;
    setTimeout(() => {
        this.innerHTML = 'Pending';
        this.disabled = false;
    }, 5000);
});

// Function to reset the form
function resetForm() {
    document.getElementById('employeeForm').reset();
    document.getElementById('formMethod').value = 'POST';
    document.getElementById('formId').value = '';

    // Handle progress container
    const progressContainer = document.getElementById('progress-container');
    if (progressContainer) {
        document.getElementById('upload-status').textContent = ''; // Clear upload status
        progressContainer.classList.add('none'); // Hide progress bar
        progressContainer.classList.remove('block');

    }
}

// Function to handle file upload progress
function handleFiles(files) {
    if (files.length) {
        const file = files[0];
        console.log('File name:', file.name);

        // Show progress container
        const progressContainer = document.getElementById('progress-container');
        if (progressContainer) {
            progressContainer.classList.remove('none');
            progressContainer.classList.add('block');
        }

        let counter = 0;
        const progress = document.getElementById('file-progress');
        const interval = setInterval(function () {
            if (counter <= 100) {
                progress.value = counter;
                counter++;
            } else {
                clearInterval(interval);
                if (progressContainer) {

                    progressContainer.classList.remove('block');
                    progressContainer.classList.add('none');// Hide progress bar
                }
                document.getElementById('upload-status').textContent = 'Uploaded successfully!';
            }
        }, 10);
    }
}


// Function to calculate age from date of birth
function calculateAge(dateOfBirth) {
    const today = new Date();
    const birthDate = new Date(dateOfBirth);
    let age = today.getFullYear() - birthDate.getFullYear();
    const monthDiff = today.getMonth() - birthDate.getMonth();
    if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birthDate.getDate())) {
        age--;
    }
    return age;
}

// Function to validate age is between 18 and 60
function validateAge(dateOfBirth) {
    const age = calculateAge(dateOfBirth);
    return age >= 18 && age <= 60;
}

// Function to generate employee ID
function generateEmployeeID(firstName, lastName, mobileNumber) {
    const firstNamePart = firstName.slice(0, 3).toLowerCase();
    const lastNamePart = lastName.slice(0, 3).toLowerCase();
    const mobileNumberPart = mobileNumber.slice(-4);
    return `${firstNamePart}${lastNamePart}${mobileNumberPart}`;
}

// Function to fill permanent address if checkbox is checked
function fillAddress() {
    if (document.getElementById('sameAddress').checked) {
        document.getElementById('PermanentAddress').value = document.getElementById('CurrentAddress').value;
    } else {
        document.getElementById('PermanentAddress').value = '';
    }
}
