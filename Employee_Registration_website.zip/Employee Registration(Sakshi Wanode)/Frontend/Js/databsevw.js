const apiBaseUrl = 'https://localhost:7200/api/employee'; // Adjust the URL to your API

// Event listener for editing an employee
document.getElementById('editEmployeeForm').addEventListener('submit', function (event) {
    event.preventDefault();
    const EmpId = document.getElementById('editEmpId').value;

    // Employee object with updated values
    const employee = {
        id: EmpId,
        firstName: document.getElementById('editFirstname').value,
        lastName: document.getElementById('editLastname').value,
        email: document.getElementById('editEmail').value,
        dob: document.getElementById('editDateOfBirth').value,
        mobileNumber: document.getElementById('editMobileNumber').value,
        alternateNumber: document.getElementById('editAlternateNumber').value,
        nationality: document.getElementById('editNationality').value,
        state: document.getElementById('editState').value,
        city: document.getElementById('editCity').value,
        pincode: document.getElementById('editPincode').value,
        companyName: document.getElementById('editCompanyName').value,
        joiningDate: document.getElementById('editJoiningDate').value,
        currentCTC: document.getElementById('editCurrentCTC').value,
        employmentType: document.getElementById('editEmploymentType').value,
        currentAddress: document.getElementById('editCurrentAddress').value,
        permanentAddress: document.getElementById('editPermanentAddress').value,
        documentType: document.getElementById('editDocumentType').value,
        documentNumber: document.getElementById('editDocumentNumber').value
    };

    updateEmployee(EmpId, employee);
});

function updateEmployee(id, employee) {
    fetch(`${apiBaseUrl}/${id}`, {
        method: 'PUT',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(employee) // Remove the curly braces around employee
    })
    .then(response => response.json())
    .then(() => {
        alert('Employee updated successfully!');
        $('#editEmployeeModal').modal('hide');
        fetchEmployeeData();
    })
    .catch(error => {
        console.error('Error updating employee:', error);
    });
}

// Event listener for delete button
document.getElementById('confirmDeleteButton').addEventListener('click', function () {
    const EmpId = this.getAttribute('data-EmpId');
    deleteEmployee(EmpId);
});

function deleteEmployee(id) {
    fetch(`${apiBaseUrl}/${id}`, {
        method: 'DELETE'
    })
    .then(() => {
        alert('Employee deleted successfully!');
        $('#deleteEmployeeModal').modal('hide');
        fetchEmployeeData();
    })
    .catch(error => {
        console.error('Error deleting employee:', error);
    });
}

// Fetch employee data and populate table
function fetchEmployeeData() {
    fetch(apiBaseUrl)
    .then(response => response.json())
    .then(data => {
        const tableBody = document.querySelector('#EmployeeTable tbody');
        tableBody.innerHTML = ''; // Clear existing data
        data.forEach(employee => {
            const row = document.createElement('tr');
            row.innerHTML = `
                <td>${employee.empId}</td>
                <td>${employee.firstname}</td>
                <td>${employee.lastname}</td>
                <td>${employee.email}</td>
                <td>${employee.dateOfBirth}</td>
                <td>${employee.mobileNumber}</td>
                <td>${employee.alternateNumber}</td>
                <td>${employee.nationality}</td>
                <td>${employee.state}</td>
                <td>${employee.city}</td>
                <td>${employee.pincode}</td>
                <td>${employee.companyName}</td>
                <td>${employee.joiningDate}</td>
                <td>${employee.currentCTC}</td>
                <td>${employee.employmentType}</td>
                <td>${employee.currentAddress}</td>
                <td>${employee.permanentAddress}</td>
                <td>${employee.documentType}</td>
                <td>${employee.documentNumber}</td>
                <td>
                    <button class="btn btn-primary btn-sm" onclick="openEditModal(${employee.empId})">
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-pencil-square" viewBox="0 0 16 16">
  <path d="M15.502 1.94a.5.5 0 0 1 0 .706L14.459 3.69l-2-2L13.502.646a.5.5 0 0 1 .707 0l1.293 1.293zm-1.75 2.456-2-2L4.939 9.21a.5.5 0 0 0-.121.196l-.805 2.414a.25.25 0 0 0 .316.316l2.414-.805a.5.5 0 0 0 .196-.12l6.813-6.814z"/>
  <path fill-rule="evenodd" d="M1 13.5A1.5 1.5 0 0 0 2.5 15h11a1.5 1.5 0 0 0 1.5-1.5v-6a.5.5 0 0 0-1 0v6a.5.5 0 0 1-.5.5h-11a.5.5 0 0 1-.5-.5v-11a.5.5 0 0 1 .5-.5H9a.5.5 0 0 0 0-1H2.5A1.5 1.5 0 0 0 1 2.5z"/>
</svg>
                       
                    </button>
                    <button class="btn btn-danger btn-sm" onclick="openDeleteModal(${employee.empId})">
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-trash3" viewBox="0 0 16 16">
                            <path d="M6.5 1h3a.5.5 0 0 1 .5.5v1H6v-1a.5.5 0 0 1 .5-.5M11 2.5v-1A1.5 1.5 0 0 0 9.5 0h-3A1.5 1.5 0 0 0 5 1.5v1H1.5a.5.5 0 0 0 0 1h.538l.853 10.66A2 2 0 0 0 4.885 16h6.23a2 2 0 0 0 1.994-1.84l.853-10.66h.538a.5.5 0 0 0 0-1zm1.958 1-.846 10.58a1 1 0 0 1-.997.92h-6.23a1 1 0 0 1-.997-.92L3.042 3.5zm-7.487 1a.5.5 0 0 1 .528.47l.5 8.5a.5.5 0 0 1-.998.06L5 5.03a.5.5 0 0 1 .47-.53Zm5.058 0a.5.5 0 0 1 .47.53l-.5 8.5a.5.5 0 1 1-.998-.06l.5-8.5a.5.5 0 0 1 .528-.47M8 4.5a.5.5 0 0 1 .5.5v8.5a.5.5 0 0 1-1 0V5a.5.5 0 0 1 .5-.5"/>
                        </svg>
                    </button>
                </td>
            `;
            tableBody.appendChild(row);
        });
    })
    .catch(error => {
        console.error('Error fetching employee data:', error);
    });
}

// Open edit modal with employee data
function openEditModal(EmpId) {
    fetch(`${apiBaseUrl}/${EmpId}`)
    .then(response => response.json())
    .then(employee => {
        document.getElementById('editEmpId').value = employee.id;
        document.getElementById('editFirstname').value = employee.firstname;
        document.getElementById('editLastname').value = employee.lastname;
        document.getElementById('editEmail').value = employee.email;
        document.getElementById('editDateOfBirth').value = formatDateForInput(employee.dateOfBirth);
        document.getElementById('editMobileNumber').value = employee.mobileNumber;
        document.getElementById('editAlternateNumber').value = employee.alternateNumber;
        document.getElementById('editNationality').value = employee.nationality;
        document.getElementById('editState').value = employee.state;
        document.getElementById('editCity').value = employee.city;
        document.getElementById('editPincode').value = employee.pincode;
        document.getElementById('editCompanyName').value = employee.companyName;
        document.getElementById('editJoiningDate').value = formatDateForInput(employee.joiningDate);
        document.getElementById('editCurrentCTC').value = employee.currentCTC;
        document.getElementById('editEmploymentType').value = employee.employmentType;
        document.getElementById('editCurrentAddress').value = employee.currentAddress;
        document.getElementById('editPermanentAddress').value = employee.permanentAddress;
        document.getElementById('editDocumentType').value = employee.documentType;
        document.getElementById('editDocumentNumber').value = employee.documentNumber;

        $('#editEmployeeModal').modal('show');
    })
    .catch(error => {
        console.error('Error fetching employee data:', error);
    });
}

// Format date to YYYY-MM-DD for input[type="date"]
function formatDateForInput(dateString) {
    const date = new Date(dateString);
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const day = String(date.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
}
// Function to open the delete confirmation modal
function openDeleteModal(EmpId) {
    const confirmDeleteButton = document.getElementById('confirmDeleteButton');
    
    // Reset the button click event to ensure no duplicate handlers
    confirmDeleteButton.onclick = function() {
        deleteEmployee(EmpId);
    };
    
    // Show the modal
    $('#deleteEmployeeModal').modal('show');
}
// Function to handle the employee deletion
async function deleteEmployee(EmpId) {
    try {
        // Make an API call to delete the employee
        const response = await fetch(`https://localhost:7200/api/Employee/${EmpId}`, {
            method: 'DELETE',
            headers: {
                'Content-Type': 'application/json',
            },
        });

        if (response.ok) {
            // Employee was successfully deleted
            console.log(`Employee with ID ${EmpId} deleted.`);

            // Close the modal after deletion is confirmed
            $('#deleteEmployeeModal').modal('hide');

            // Optionally, refresh the employee list or give a success message
            alert('Deleted Successfully!');
            // You might want to refresh the list of employees here
            fetchEmployeeData();
        } else {
            // Handle errors if the delete request failed
            const errorMessage = await response.text();
            console.error('Failed to delete employee:', errorMessage);
           
        }
    } catch (error) {
        // Handle network or other errors
        console.error('Error:', error);
        alert('An error occurred while deleting the employee. Please try again.');
    }
}


// Initial fetch of employee data
fetchEmployeeData();
